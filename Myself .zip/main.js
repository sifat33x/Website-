<script>
  // Example: Alert when login button clicked
  document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.querySelector('.login .button');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        alert('Login button clicked!');
      });
    }
  });
</script>